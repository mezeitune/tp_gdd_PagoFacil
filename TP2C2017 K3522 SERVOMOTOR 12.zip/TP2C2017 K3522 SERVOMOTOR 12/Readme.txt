
Numero Grupo: 12

Integrantes:
-Ayala, Ignacio (156.106-6)  Curso: K3573
-Chen, Fernando (155.592-3)  Curso: K3522
-Zeitune, Matias (156.845-0) Curso: K3522

Email: matizeitune@gmail.com