﻿namespace PagoAgilFrba.AbmCliente
{
    partial class AltaCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtNombreCliente = new System.Windows.Forms.TextBox();
            this.txtApellidoCliente = new System.Windows.Forms.TextBox();
            this.txtDNICliente = new System.Windows.Forms.TextBox();
            this.txtMailCliente = new System.Windows.Forms.TextBox();
            this.txtTelCliente = new System.Windows.Forms.TextBox();
            this.txtCalleCliente = new System.Windows.Forms.TextBox();
            this.txtNroPisoCliente = new System.Windows.Forms.TextBox();
            this.txtDptoCliente = new System.Windows.Forms.TextBox();
            this.txtLocalidadCliente = new System.Windows.Forms.TextBox();
            this.txtCodPostalCliente = new System.Windows.Forms.TextBox();
            this.DarAltaCliente = new System.Windows.Forms.Button();
            this.FechaNacCliente = new System.Windows.Forms.DateTimePicker();
            this.limpiar = new System.Windows.Forms.Button();
            this.volverALaPaginaAnterior = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(473, 160);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 15);
            this.label1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 38);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 74);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Apellido";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 112);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "DNI";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 147);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Mail";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 183);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Telefono";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 224);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "Calle";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 258);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 15);
            this.label8.TabIndex = 7;
            this.label8.Text = "Numero de piso";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 295);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 15);
            this.label9.TabIndex = 8;
            this.label9.Text = "Departamento";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(29, 330);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 15);
            this.label10.TabIndex = 9;
            this.label10.Text = "Localidad";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(29, 366);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 15);
            this.label11.TabIndex = 10;
            this.label11.Text = "Codigo postal";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(29, 406);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(239, 15);
            this.label12.TabIndex = 11;
            this.label12.Text = "Fecha Nacimiento (DD-MM-AAAA)";
            // 
            // txtNombreCliente
            // 
            this.txtNombreCliente.Location = new System.Drawing.Point(140, 35);
            this.txtNombreCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNombreCliente.Name = "txtNombreCliente";
            this.txtNombreCliente.Size = new System.Drawing.Size(256, 25);
            this.txtNombreCliente.TabIndex = 12;
            // 
            // txtApellidoCliente
            // 
            this.txtApellidoCliente.Location = new System.Drawing.Point(140, 68);
            this.txtApellidoCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtApellidoCliente.Name = "txtApellidoCliente";
            this.txtApellidoCliente.Size = new System.Drawing.Size(256, 25);
            this.txtApellidoCliente.TabIndex = 13;
            // 
            // txtDNICliente
            // 
            this.txtDNICliente.Location = new System.Drawing.Point(140, 100);
            this.txtDNICliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtDNICliente.Name = "txtDNICliente";
            this.txtDNICliente.Size = new System.Drawing.Size(256, 25);
            this.txtDNICliente.TabIndex = 14;
            // 
            // txtMailCliente
            // 
            this.txtMailCliente.Location = new System.Drawing.Point(140, 138);
            this.txtMailCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtMailCliente.Name = "txtMailCliente";
            this.txtMailCliente.Size = new System.Drawing.Size(256, 25);
            this.txtMailCliente.TabIndex = 15;
            // 
            // txtTelCliente
            // 
            this.txtTelCliente.Location = new System.Drawing.Point(140, 175);
            this.txtTelCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTelCliente.Name = "txtTelCliente";
            this.txtTelCliente.Size = new System.Drawing.Size(256, 25);
            this.txtTelCliente.TabIndex = 16;
            // 
            // txtCalleCliente
            // 
            this.txtCalleCliente.Location = new System.Drawing.Point(140, 216);
            this.txtCalleCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCalleCliente.Name = "txtCalleCliente";
            this.txtCalleCliente.Size = new System.Drawing.Size(256, 25);
            this.txtCalleCliente.TabIndex = 17;
            // 
            // txtNroPisoCliente
            // 
            this.txtNroPisoCliente.Location = new System.Drawing.Point(140, 255);
            this.txtNroPisoCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNroPisoCliente.Name = "txtNroPisoCliente";
            this.txtNroPisoCliente.Size = new System.Drawing.Size(256, 25);
            this.txtNroPisoCliente.TabIndex = 18;
            // 
            // txtDptoCliente
            // 
            this.txtDptoCliente.Location = new System.Drawing.Point(140, 292);
            this.txtDptoCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtDptoCliente.Name = "txtDptoCliente";
            this.txtDptoCliente.Size = new System.Drawing.Size(256, 25);
            this.txtDptoCliente.TabIndex = 19;
            // 
            // txtLocalidadCliente
            // 
            this.txtLocalidadCliente.Location = new System.Drawing.Point(140, 330);
            this.txtLocalidadCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtLocalidadCliente.Name = "txtLocalidadCliente";
            this.txtLocalidadCliente.Size = new System.Drawing.Size(256, 25);
            this.txtLocalidadCliente.TabIndex = 20;
            // 
            // txtCodPostalCliente
            // 
            this.txtCodPostalCliente.Location = new System.Drawing.Point(140, 362);
            this.txtCodPostalCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCodPostalCliente.Name = "txtCodPostalCliente";
            this.txtCodPostalCliente.Size = new System.Drawing.Size(256, 25);
            this.txtCodPostalCliente.TabIndex = 21;
            // 
            // DarAltaCliente
            // 
            this.DarAltaCliente.Location = new System.Drawing.Point(236, 453);
            this.DarAltaCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DarAltaCliente.Name = "DarAltaCliente";
            this.DarAltaCliente.Size = new System.Drawing.Size(145, 39);
            this.DarAltaCliente.TabIndex = 23;
            this.DarAltaCliente.Text = "Dar de alta cliente";
            this.DarAltaCliente.UseVisualStyleBackColor = true;
            this.DarAltaCliente.Click += new System.EventHandler(this.DarAltaCliente_Click);
            // 
            // FechaNacCliente
            // 
            this.FechaNacCliente.Location = new System.Drawing.Point(293, 399);
            this.FechaNacCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.FechaNacCliente.Name = "FechaNacCliente";
            this.FechaNacCliente.Size = new System.Drawing.Size(265, 25);
            this.FechaNacCliente.TabIndex = 56;
            // 
            // limpiar
            // 
            this.limpiar.Location = new System.Drawing.Point(37, 460);
            this.limpiar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.limpiar.Name = "limpiar";
            this.limpiar.Size = new System.Drawing.Size(100, 27);
            this.limpiar.TabIndex = 57;
            this.limpiar.Text = "Limpiar";
            this.limpiar.UseVisualStyleBackColor = true;
            this.limpiar.Click += new System.EventHandler(this.limpiar_Click);
            // 
            // volverALaPaginaAnterior
            // 
            this.volverALaPaginaAnterior.Location = new System.Drawing.Point(508, 453);
            this.volverALaPaginaAnterior.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.volverALaPaginaAnterior.Name = "volverALaPaginaAnterior";
            this.volverALaPaginaAnterior.Size = new System.Drawing.Size(100, 27);
            this.volverALaPaginaAnterior.TabIndex = 58;
            this.volverALaPaginaAnterior.Text = "Volver";
            this.volverALaPaginaAnterior.UseVisualStyleBackColor = true;
            this.volverALaPaginaAnterior.Click += new System.EventHandler(this.volverALaPaginaAnterior_Click);
            // 
            // AltaCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 507);
            this.Controls.Add(this.volverALaPaginaAnterior);
            this.Controls.Add(this.limpiar);
            this.Controls.Add(this.FechaNacCliente);
            this.Controls.Add(this.DarAltaCliente);
            this.Controls.Add(this.txtCodPostalCliente);
            this.Controls.Add(this.txtLocalidadCliente);
            this.Controls.Add(this.txtDptoCliente);
            this.Controls.Add(this.txtNroPisoCliente);
            this.Controls.Add(this.txtCalleCliente);
            this.Controls.Add(this.txtTelCliente);
            this.Controls.Add(this.txtMailCliente);
            this.Controls.Add(this.txtDNICliente);
            this.Controls.Add(this.txtApellidoCliente);
            this.Controls.Add(this.txtNombreCliente);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "AltaCliente";
            this.Text = "AltaCliente";
            this.Load += new System.EventHandler(this.AltaCliente_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtNombreCliente;
        private System.Windows.Forms.TextBox txtApellidoCliente;
        private System.Windows.Forms.TextBox txtDNICliente;
        private System.Windows.Forms.TextBox txtMailCliente;
        private System.Windows.Forms.TextBox txtTelCliente;
        private System.Windows.Forms.TextBox txtCalleCliente;
        private System.Windows.Forms.TextBox txtNroPisoCliente;
        private System.Windows.Forms.TextBox txtDptoCliente;
        private System.Windows.Forms.TextBox txtLocalidadCliente;
        private System.Windows.Forms.TextBox txtCodPostalCliente;
        private System.Windows.Forms.Button DarAltaCliente;
        private System.Windows.Forms.DateTimePicker FechaNacCliente;
        private System.Windows.Forms.Button limpiar;
        private System.Windows.Forms.Button volverALaPaginaAnterior;
    }
}