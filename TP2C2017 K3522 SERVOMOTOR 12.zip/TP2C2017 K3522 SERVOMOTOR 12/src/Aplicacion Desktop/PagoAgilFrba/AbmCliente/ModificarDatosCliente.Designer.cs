﻿namespace PagoAgilFrba.AbmCliente
{
    partial class ModificarDatosCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ModificarCliente = new System.Windows.Forms.Button();
            this.txtCodPostalCliente = new System.Windows.Forms.TextBox();
            this.txtLocalidadCliente = new System.Windows.Forms.TextBox();
            this.txtDptoCliente = new System.Windows.Forms.TextBox();
            this.txtNroPisoCliente = new System.Windows.Forms.TextBox();
            this.txtCalleCliente = new System.Windows.Forms.TextBox();
            this.txtTelCliente = new System.Windows.Forms.TextBox();
            this.txtMailCliente = new System.Windows.Forms.TextBox();
            this.txtApellidoCliente = new System.Windows.Forms.TextBox();
            this.txtNombreCliente = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.limpiar = new System.Windows.Forms.Button();
            this.volverALaPaginaAnterior = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.FechaNacCliente = new System.Windows.Forms.DateTimePicker();
            this.Habilitar = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // ModificarCliente
            // 
            this.ModificarCliente.Location = new System.Drawing.Point(267, 434);
            this.ModificarCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ModificarCliente.Name = "ModificarCliente";
            this.ModificarCliente.Size = new System.Drawing.Size(145, 39);
            this.ModificarCliente.TabIndex = 47;
            this.ModificarCliente.Text = "Modificar cliente";
            this.ModificarCliente.UseVisualStyleBackColor = true;
            this.ModificarCliente.Click += new System.EventHandler(this.ModificarCliente_Click);
            // 
            // txtCodPostalCliente
            // 
            this.txtCodPostalCliente.Location = new System.Drawing.Point(181, 329);
            this.txtCodPostalCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCodPostalCliente.Name = "txtCodPostalCliente";
            this.txtCodPostalCliente.Size = new System.Drawing.Size(256, 25);
            this.txtCodPostalCliente.TabIndex = 45;
            // 
            // txtLocalidadCliente
            // 
            this.txtLocalidadCliente.Location = new System.Drawing.Point(181, 297);
            this.txtLocalidadCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtLocalidadCliente.Name = "txtLocalidadCliente";
            this.txtLocalidadCliente.Size = new System.Drawing.Size(256, 25);
            this.txtLocalidadCliente.TabIndex = 44;
            // 
            // txtDptoCliente
            // 
            this.txtDptoCliente.Location = new System.Drawing.Point(181, 258);
            this.txtDptoCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtDptoCliente.Name = "txtDptoCliente";
            this.txtDptoCliente.Size = new System.Drawing.Size(256, 25);
            this.txtDptoCliente.TabIndex = 43;
            // 
            // txtNroPisoCliente
            // 
            this.txtNroPisoCliente.Location = new System.Drawing.Point(181, 222);
            this.txtNroPisoCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNroPisoCliente.Name = "txtNroPisoCliente";
            this.txtNroPisoCliente.Size = new System.Drawing.Size(256, 25);
            this.txtNroPisoCliente.TabIndex = 42;
            // 
            // txtCalleCliente
            // 
            this.txtCalleCliente.Location = new System.Drawing.Point(181, 182);
            this.txtCalleCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCalleCliente.Name = "txtCalleCliente";
            this.txtCalleCliente.Size = new System.Drawing.Size(256, 25);
            this.txtCalleCliente.TabIndex = 41;
            // 
            // txtTelCliente
            // 
            this.txtTelCliente.Location = new System.Drawing.Point(181, 142);
            this.txtTelCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTelCliente.Name = "txtTelCliente";
            this.txtTelCliente.Size = new System.Drawing.Size(256, 25);
            this.txtTelCliente.TabIndex = 40;
            // 
            // txtMailCliente
            // 
            this.txtMailCliente.Location = new System.Drawing.Point(181, 105);
            this.txtMailCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtMailCliente.Name = "txtMailCliente";
            this.txtMailCliente.Size = new System.Drawing.Size(256, 25);
            this.txtMailCliente.TabIndex = 39;
            // 
            // txtApellidoCliente
            // 
            this.txtApellidoCliente.Location = new System.Drawing.Point(181, 65);
            this.txtApellidoCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtApellidoCliente.Name = "txtApellidoCliente";
            this.txtApellidoCliente.Size = new System.Drawing.Size(256, 25);
            this.txtApellidoCliente.TabIndex = 37;
            // 
            // txtNombreCliente
            // 
            this.txtNombreCliente.Location = new System.Drawing.Point(188, -68);
            this.txtNombreCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNombreCliente.Name = "txtNombreCliente";
            this.txtNombreCliente.Size = new System.Drawing.Size(256, 25);
            this.txtNombreCliente.TabIndex = 36;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(71, 373);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(239, 15);
            this.label12.TabIndex = 35;
            this.label12.Text = "Fecha Nacimiento (DD-MM-AAAA)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(71, 332);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 15);
            this.label11.TabIndex = 34;
            this.label11.Text = "Codigo postal";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(71, 297);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 15);
            this.label10.TabIndex = 33;
            this.label10.Text = "Localidad";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(71, 262);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 15);
            this.label9.TabIndex = 32;
            this.label9.Text = "Departamento";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(71, 225);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 15);
            this.label8.TabIndex = 31;
            this.label8.Text = "Numero de piso";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(71, 190);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 15);
            this.label7.TabIndex = 30;
            this.label7.Text = "Calle";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(71, 150);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 15);
            this.label6.TabIndex = 29;
            this.label6.Text = "Telefono";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(71, 113);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 15);
            this.label5.TabIndex = 28;
            this.label5.Text = "Mail";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(71, 70);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 15);
            this.label3.TabIndex = 26;
            this.label3.Text = "Apellido";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, -65);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 25;
            this.label2.Text = "Nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(515, 127);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 15);
            this.label1.TabIndex = 24;
            // 
            // limpiar
            // 
            this.limpiar.Location = new System.Drawing.Point(75, 441);
            this.limpiar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.limpiar.Name = "limpiar";
            this.limpiar.Size = new System.Drawing.Size(100, 27);
            this.limpiar.TabIndex = 58;
            this.limpiar.Text = "Limpiar";
            this.limpiar.UseVisualStyleBackColor = true;
            this.limpiar.Click += new System.EventHandler(this.limpiar_Click);
            // 
            // volverALaPaginaAnterior
            // 
            this.volverALaPaginaAnterior.Location = new System.Drawing.Point(499, 441);
            this.volverALaPaginaAnterior.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.volverALaPaginaAnterior.Name = "volverALaPaginaAnterior";
            this.volverALaPaginaAnterior.Size = new System.Drawing.Size(100, 27);
            this.volverALaPaginaAnterior.TabIndex = 59;
            this.volverALaPaginaAnterior.Text = "Volver";
            this.volverALaPaginaAnterior.UseVisualStyleBackColor = true;
            this.volverALaPaginaAnterior.Click += new System.EventHandler(this.volverALaPaginaAnterior_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(77, 30);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 15);
            this.label4.TabIndex = 60;
            this.label4.Text = "Nombre";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(181, 27);
            this.txtNombre.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(256, 25);
            this.txtNombre.TabIndex = 61;
            // 
            // FechaNacCliente
            // 
            this.FechaNacCliente.Location = new System.Drawing.Point(332, 366);
            this.FechaNacCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.FechaNacCliente.Name = "FechaNacCliente";
            this.FechaNacCliente.Size = new System.Drawing.Size(265, 25);
            this.FechaNacCliente.TabIndex = 56;
            // 
            // Habilitar
            // 
            this.Habilitar.AutoSize = true;
            this.Habilitar.Location = new System.Drawing.Point(75, 402);
            this.Habilitar.Name = "Habilitar";
            this.Habilitar.Size = new System.Drawing.Size(165, 19);
            this.Habilitar.TabIndex = 62;
            this.Habilitar.Text = "&Habilitar cliente";
            this.Habilitar.UseVisualStyleBackColor = true;
            // 
            // ModificarDatosCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(655, 508);
            this.Controls.Add(this.Habilitar);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.volverALaPaginaAnterior);
            this.Controls.Add(this.limpiar);
            this.Controls.Add(this.FechaNacCliente);
            this.Controls.Add(this.ModificarCliente);
            this.Controls.Add(this.txtCodPostalCliente);
            this.Controls.Add(this.txtLocalidadCliente);
            this.Controls.Add(this.txtDptoCliente);
            this.Controls.Add(this.txtNroPisoCliente);
            this.Controls.Add(this.txtCalleCliente);
            this.Controls.Add(this.txtTelCliente);
            this.Controls.Add(this.txtMailCliente);
            this.Controls.Add(this.txtApellidoCliente);
            this.Controls.Add(this.txtNombreCliente);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "ModificarDatosCliente";
            this.Text = "ModificarDatosCliente";
            this.Load += new System.EventHandler(this.ModificarDatosCliente_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ModificarCliente;
        private System.Windows.Forms.TextBox txtCodPostalCliente;
        private System.Windows.Forms.TextBox txtLocalidadCliente;
        private System.Windows.Forms.TextBox txtDptoCliente;
        private System.Windows.Forms.TextBox txtNroPisoCliente;
        private System.Windows.Forms.TextBox txtCalleCliente;
        private System.Windows.Forms.TextBox txtTelCliente;
        private System.Windows.Forms.TextBox txtMailCliente;
        private System.Windows.Forms.TextBox txtApellidoCliente;
        private System.Windows.Forms.TextBox txtNombreCliente;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button limpiar;
        private System.Windows.Forms.Button volverALaPaginaAnterior;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.DateTimePicker FechaNacCliente;
        public System.Windows.Forms.CheckBox Habilitar;
    }
}